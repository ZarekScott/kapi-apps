exports.handler = async (event, context) => {
  try {
    const user = context.clientContext && context.clientContext.user;
    if (!user) return { statusCode: 401, body: "Unauthorized" };

    const roles = (user.app_metadata && user.app_metadata.roles) || [];
    const email = (user.email || "").toLowerCase();
    const adminEmails = (process.env.ADMIN_EMAILS || "")
      .toLowerCase()
      .split(",")
      .map(s => s.trim())
      .filter(Boolean);

    const isAdmin = roles.includes("admin") || adminEmails.includes(email);
    if (!isAdmin) return { statusCode: 403, body: "Forbidden" };

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ ok: true, email, roles })
    };
  } catch (err) {
    return { statusCode: 500, body: `Server error: ${err.message}` };
  }
};
