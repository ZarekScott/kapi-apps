Kapi Auth + Admin Bundle
========================

Files included:
- netlify/functions/admin.js
- admin/index.html
- confirm.html
- assets/js/token-handler.js

Setup:
1) Put these files in your repo at the same paths.
2) Netlify → Site configuration → Environment variables:
   ADMIN_EMAILS = your@email.com
3) Netlify → Identity → Emails:
   - Confirmation link/button:
     {{ .SiteURL }}/confirm.html#confirmation_token={{ .Token }}
   - Recovery link/button:
     {{ .SiteURL }}/confirm.html#recovery_token={{ .Token }}
4) Add this snippet on pages that use Identity:
   <script>
     window.netlifyIdentitySettings = {
       APIUrl: 'https://kapi-apps.netlify.app/.netlify/identity'
     };
   </script>
   <script src="https://identity.netlify.com/v1/netlify-identity-widget.js"></script>
