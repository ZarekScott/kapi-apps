// assets/js/token-handler.js
(function(){
  const hash = (window.location.hash || '').replace(/^#/, '');
  if (!hash) return;
  const p = new URLSearchParams(hash);
  const confirm = p.get('confirmation_token');
  const recovery = p.get('recovery_token') || (p.get('type') === 'recovery' && p.get('access_token'));
  function ensureGoTrue(cb){
    if (window.GoTrue) return cb();
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/gotrue-js/dist/gotrue.min.js';
    s.onload = cb;
    document.head.appendChild(s);
  }
  if (confirm) {
    ensureGoTrue(() => {
      const auth = new window.GoTrue({ APIUrl: 'https://kapi-apps.netlify.app/.netlify/identity' });
      auth.confirm(confirm)
        .then(() => window.location.replace('/apps.html'))
        .catch(err => alert('Verification failed: ' + (err && err.message || '')));
    });
    return;
  }
  if (recovery) {
    window.location.replace('/reset.html#recovery_token=' + encodeURIComponent(recovery));
  }
})();
